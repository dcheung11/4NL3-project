import os
import pandas as pd
import sys

def ingest():
    # Define paths
    submission_dir = "/app/ingested_program"  # Directory where participant submissions are stored
    output_dir = "/app/output/"  # Directory to save processed data for scoring
    program_dir = '/app/program'

    sys.path.append(output_dir)
    sys.path.append(program_dir)
    sys.path.append(submission_dir)

    # Ensure output directory exists
    os.makedirs(output_dir, exist_ok=True)

    # Check if the input directory exists
    if not os.path.exists(submission_dir):
        raise FileNotFoundError(f"Input directory {submission_dir} does not exist. No submissions were uploaded.")

    # Get all CSV files in the input directory
    submission_files = [f for f in os.listdir(submission_dir) if f.endswith('.csv')]

    if not submission_files:
        raise FileNotFoundError("No CSV file found in the input directory.")

    if len(submission_files) > 1:
        raise ValueError("Only one CSV file is allowed in the input directory.")

    # Process the first CSV file found
    submission_file = os.path.join(submission_dir, submission_files[0])
    try:
        predictions = pd.read_csv(submission_file)
    except Exception as e:
        raise ValueError(f"Failed to read {submission_files[0]}: {e}")

    # Save the predictions to the output directory for scoring
    output_file = os.path.join(output_dir, "predictions.csv")
    predictions.to_csv(output_file, index=False)

if __name__ == "__main__":
    ingest()