# Data

Our data is in .csv format. 

The first row displays the categories:
- Non Toxic
- Toxicity/Severe Toxicity
- Identity Attacks
- Sexual Harassment
- Insults
- Proafanity including racial slurs
- Threats to people's safety
- Sexually Explicit

The first column of each row refers to the Tweet that is in text format.

The following is a representation of an annotated dataset.

| Tweets To Be Annotated | Non_Toxic |Toxicity|Severe_Toxicity|Identity_Attack|Insult|Profanity|Threat|Sexually_Explicit|
|------------------------|-----------|---|---|---|---|---|---|---|
| Tweet                  | 0,1       | ...|
| Tweet               | ... |
| ... |

You have access to the following files to train your model:
- train.csv
- val.csv
- test.csv (this is the data your submission should be a result of)
- train_ground_truth.csv
- val_ground_truth.csv

the ground truth files are the 'solutions' to the train and validation sets.

train/val/test.csv consist of only the tweets.
train_/val_ground_truth.csv consist of only the labels/annotated results.