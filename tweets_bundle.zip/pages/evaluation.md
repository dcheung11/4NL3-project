# Evaluation

* Your predictions MUST match the ground_truth.csv format (keep labels consistent)


Your submitted results against the train.csv set are scored against our ground truth results using the following metrics:

The scoring metrics used are F1 and the [accuracy score](https://scikit-learn.org/stable/modules/generated/sklearn.metrics.accuracy_score.html).

Your model is evaluated on how well each label is predicted. The results are outputted as a JSON file.
- e.g. {"accuracy_Non_Toxic": 0.39285714285714285, "f1_score_Non_Toxic": 0.36250000000000004, ...}
