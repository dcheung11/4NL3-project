import os
import json
import numpy as np
import pandas as pd
from sklearn.metrics import accuracy_score, f1_score

# Define paths
#output_dir = '/app/output'  # Directory where predictions are saved
#reference_dir = '/app/reference_data'  # Directory containing ground truth data
input_dir = '/app/input'    # Input from ingestion program
output_dir = '/app/output/' # To write the scores
reference_dir = os.path.join(input_dir, 'ref')  # Ground truth data
prediction_dir = os.path.join(input_dir, 'res') # Prediction made by the model

# debugging files not found
print("Directory structure of /app:")
for root, dirs, files in os.walk('/app'):
    print(f"Directory: {root}")
    for file in files:
        print(f"  File: {file}")

def score():
    # Load ground truth
    ground_truth_file = os.path.join(reference_dir, "test_ground_truth.csv")
    if not os.path.exists(ground_truth_file):
        raise FileNotFoundError(f"Ground truth file {ground_truth_file} does not exist.")

    ground_truth = pd.read_csv(ground_truth_file)

    # Load predictions
    predictions_file = os.path.join(prediction_dir, "predictions.csv")
    if not os.path.exists(predictions_file):
        raise FileNotFoundError(f"Predictions file {predictions_file} does not exist.")

    predictions = pd.read_csv(predictions_file)

    # Ensure the predictions and ground truth are aligned
    if len(predictions) != len(ground_truth):
        raise ValueError("Predictions and ground truth have different lengths.")

    # Ensure the columns match
    if list(predictions.columns) != list(ground_truth.columns):
        raise ValueError("Predictions and ground truth columns do not match.")

    # Compute evaluation metrics for each category
    scores = {}
    for column in ground_truth.columns:
        scores[f"accuracy_{column}"] = accuracy_score(ground_truth[column], predictions[column])
        scores[f"f1_score_{column}"] = f1_score(ground_truth[column], predictions[column], average='binary')

    # Save scores to a file
    scores_file = os.path.join(output_dir, "scores.json")
    with open(scores_file, "w") as f:
        json.dump(scores, f)

if __name__ == "__main__":
    print("Starting scoring program")
    score()
    print("Scoring finished")


